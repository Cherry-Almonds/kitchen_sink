#!/bin/bash
VERBOSE=0
SEARCH_DIR=""
while [[ "$#" -gt 0 ]]; do
    case "$1" in
        -v|--verbose)
            VERBOSE=1
            shift
            ;;
        -*)
            echo "Unknown option: $1" >&2
            echo "Usage: $0 [-v|--verbose] [search_dir]" >&2
            exit 1
            ;;
        *)
            SEARCH_DIR="$1"
            shift
            ;;
    esac
done
SEARCH_DIR="${SEARCH_DIR:-/}"
echo -e "\n========================================================"
if [ "$VERBOSE" -eq 1 ]; then
    echo -e ""
else
    echo -e " Scanning system for: .db, .conf, .dav, .sh, .htpasswd, .php, .ini, .properties, .rdg, .txt, .yml (Standard Mode)"
fi
echo -e " Target Path: \033[1m$SEARCH_DIR\033[0m (Errors filtered out)"
echo -e "========================================================"
find "$SEARCH_DIR" -type f \( \
    -name "*.db" -o \
    -name "*.conf" -o \
    -name "*.dav" -o \
    -name "*.sh" -o \
    -name "*.htpasswd" -o \
    -name "*.php" -o \
    -name "*.ini" -o \
    -name "*.properties" -o \
    -name "*.rdg" -o \
    -name "*.txt" -o \
    -name "*.yml" \) 2>/dev/null | while read -r file; do
    if [ "$VERBOSE" -eq 0 ]; then
        case "$file" in
            /usr/*|/etc/*|/run/*) continue ;;
        esac
    fi
    ext="${file##*.}"
    ext=$(echo "$ext" | tr '[:upper:]' '[:lower:]')
    owner=$(stat -c "%U" "$file" 2>/dev/null || stat -f "%Su" "$file" 2>/dev/null)
    [ -z "$owner" ] && owner="unknown"

    if [ "$VERBOSE" -eq 0 ] && [ "$owner" = "man" ]; then
        continue
    fi
    perms=$(stat -c "%A" "$file" 2>/dev/null || stat -f "%Sp" "$file" 2>/dev/null)
    [ -z "$perms" ] && perms="---------"
    if echo "$file" | grep -qE -i '(config|passwd|db|secrets|secret|grafana|password|htuser|vault|user)'; then
        kw_flag="1"
    else
        kw_flag="0"
    fi
    if [ "$owner" = "root" ]; then
        prio="0"
    else
        prio="1"
    fi
    echo "$ext|$kw_flag|$prio|$owner|$perms|$file"
done | sort -t'|' -k1,1 -k2,2n -k3,3n -k4,4 -k6,6 | {
    current_ext=""
    while IFS='|' read -r ext kw_flag prio owner perms file; do
        if [ "$ext" != "$current_ext" ]; then
            current_ext="$ext"
            ext_upper=$(echo "$current_ext" | tr '[:lower:]' '[:upper:]')
            echo -e "\n\033[1;44m === [ .${ext_upper} FILES ] === \033[0m"
        fi
        highlighted_file=$(echo "$file" | sed -E 's/([cC][oO][nN][fF][iI][gG]|[pP][aA][sS][sS][wW][dD]|[dD][bB]|[sS][eE][cC][rR][eE][tT][sS]?|[gG][rR][aA][fF][aA][nN][aA]|[pP][aA][sS][sS][wW][oO][rR][dD]|[hH][tT][uU][sS][eE][rR][sS]?|[vV][aA][uU][lL][tT]|[uU][sS][eE][rR])/\x1b[1;33;41m\1\x1b[0m/g')

        if [ "$owner" = "root" ]; then
            echo -e "    \033[1;31m[root]\033[0m  \033[35m${perms}\033[0m  $highlighted_file"
        else
            echo -e "    \033[32m[${owner}]\033[0m  \033[35m${perms}\033[0m  $highlighted_file"
        fi
    done
}

echo -e "\n--------------------------------------------------------"
echo -e " Scan Complete!\n If you want verbose output, try again with -v. You'll get everything though...."
